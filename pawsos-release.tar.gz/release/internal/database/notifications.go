package database

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"github.com/google/uuid"
	"pawsos/internal/models"
)

type NotificationJob struct {
	ID             string
	ReportID       string
	IdempotencyKey string
	Channel        string
	Type           string
	Recipient      string
	Payload        json.RawMessage
	Status         string
	Attempts       int
	NextAttemptAt  time.Time
	LastError      string
	ProviderRef    string
	CreatedAt      time.Time
	UpdatedAt      time.Time
}

func (db *DB) EnqueueNotification(ctx context.Context, job NotificationJob) error {
	if job.ID == "" {
		job.ID = uuid.NewString()
	}
	if job.Status == "" {
		job.Status = "pending"
	}
	now := time.Now().UTC()
	if job.CreatedAt.IsZero() {
		job.CreatedAt = now
	}
	if job.UpdatedAt.IsZero() {
		job.UpdatedAt = now
	}
	if job.NextAttemptAt.IsZero() {
		job.NextAttemptAt = now
	}
	query := db.rebind(`
		INSERT INTO notification_jobs (
			id, report_id, idempotency_key, channel, notification_type, recipient, payload,
			status, attempts, next_attempt_at, last_error, provider_reference, created_at, updated_at
		) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
		ON CONFLICT(idempotency_key) DO NOTHING
	`)
	_, err := db.ExecContext(ctx, query, job.ID, job.ReportID, job.IdempotencyKey, job.Channel,
		job.Type, job.Recipient, string(job.Payload), job.Status, job.Attempts, job.NextAttemptAt,
		nullableString(job.LastError), nullableString(job.ProviderRef), job.CreatedAt, job.UpdatedAt)
	return err
}

func nullableString(value string) interface{} {
	if value == "" {
		return nil
	}
	return value
}

func (db *DB) CreateAdminNotifications(ctx context.Context, reportID, eventKey, title, body string) error {
	rows, err := db.QueryContext(ctx, db.rebind("SELECT id FROM users WHERE role = ? AND verified = ?"),
		string(models.RoleAdmin), true)
	if err != nil {
		return err
	}
	var adminIDs []string
	for rows.Next() {
		var id string
		if err := rows.Scan(&id); err != nil {
			rows.Close()
			return err
		}
		adminIDs = append(adminIDs, id)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return err
	}
	if err := rows.Close(); err != nil {
		return err
	}
	query := db.rebind(`
		INSERT INTO site_notifications (id, user_id, report_id, event_key, title, body, created_at)
		VALUES (?, ?, ?, ?, ?, ?, ?)
		ON CONFLICT(user_id, event_key) DO NOTHING
	`)
	now := time.Now().UTC()
	for _, id := range adminIDs {
		if _, err := db.ExecContext(ctx, query, uuid.NewString(), id, reportID, eventKey, title, body, now); err != nil {
			return err
		}
	}
	return nil
}

func (db *DB) ListSiteNotifications(ctx context.Context, userID string, limit int) ([]models.SiteNotification, error) {
	if limit < 1 || limit > 100 {
		limit = 50
	}
	query := db.rebind(`
		SELECT id, report_id, title, body, read_at, created_at
		FROM site_notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?
	`)
	rows, err := db.QueryContext(ctx, query, userID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var notifications []models.SiteNotification
	for rows.Next() {
		var item models.SiteNotification
		var readAt sql.NullTime
		if err := rows.Scan(&item.ID, &item.ReportID, &item.Title, &item.Body, &readAt, &item.CreatedAt); err != nil {
			return nil, err
		}
		if readAt.Valid {
			item.ReadAt = &readAt.Time
		}
		notifications = append(notifications, item)
	}
	return notifications, rows.Err()
}

func (db *DB) MarkSiteNotificationRead(ctx context.Context, userID, notificationID string) error {
	query := db.rebind("UPDATE site_notifications SET read_at = ? WHERE id = ? AND user_id = ? AND read_at IS NULL")
	result, err := db.ExecContext(ctx, query, time.Now().UTC(), notificationID, userID)
	if err != nil {
		return err
	}
	affected, err := result.RowsAffected()
	if err != nil {
		return err
	}
	if affected > 0 {
		return nil
	}
	var exists int
	err = db.QueryRowContext(ctx, db.rebind("SELECT 1 FROM site_notifications WHERE id = ? AND user_id = ?"), notificationID, userID).Scan(&exists)
	if errors.Is(err, sql.ErrNoRows) {
		return ErrNotFound
	}
	return err
}

func (db *DB) ClaimDueNotifications(ctx context.Context, limit int) ([]NotificationJob, error) {
	if limit < 1 || limit > 50 {
		limit = 10
	}
	now := time.Now().UTC()
	staleBefore := now.Add(-10 * time.Minute)
	query := `
		SELECT id, report_id, idempotency_key, channel, notification_type, recipient, payload,
		       status, attempts, next_attempt_at, last_error, provider_reference, created_at, updated_at
		FROM notification_jobs
		WHERE (status = 'pending' AND next_attempt_at <= ?) OR (status = 'processing' AND updated_at <= ?)
		ORDER BY next_attempt_at ASC LIMIT ?
	`
	if db.driver == "postgres" {
		query += " FOR UPDATE SKIP LOCKED"
	}
	tx, err := db.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()
	rows, err := tx.QueryContext(ctx, db.rebind(query), now, staleBefore, limit)
	if err != nil {
		return nil, err
	}
	var jobs []NotificationJob
	for rows.Next() {
		var job NotificationJob
		var payload string
		var lastError, providerRef sql.NullString
		if err := rows.Scan(&job.ID, &job.ReportID, &job.IdempotencyKey, &job.Channel,
			&job.Type, &job.Recipient, &payload, &job.Status, &job.Attempts,
			&job.NextAttemptAt, &lastError, &providerRef, &job.CreatedAt, &job.UpdatedAt); err != nil {
			rows.Close()
			return nil, err
		}
		job.Payload = json.RawMessage(payload)
		if lastError.Valid {
			job.LastError = lastError.String
		}
		if providerRef.Valid {
			job.ProviderRef = providerRef.String
		}
		jobs = append(jobs, job)
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, err
	}
	if err := rows.Close(); err != nil {
		return nil, err
	}
	update := db.rebind("UPDATE notification_jobs SET status = 'processing', attempts = attempts + 1, updated_at = ? WHERE id = ?")
	for i := range jobs {
		if _, err := tx.ExecContext(ctx, update, now, jobs[i].ID); err != nil {
			return nil, err
		}
		jobs[i].Attempts++
		jobs[i].Status = "processing"
	}
	if err := tx.Commit(); err != nil {
		return nil, err
	}
	return jobs, nil
}

func (db *DB) CompleteNotification(ctx context.Context, id, status, message, providerRef string, nextAttempt time.Time) error {
	if status != "pending" && status != "sent" && status != "failed" {
		return fmt.Errorf("invalid notification status %q", status)
	}
	query := db.rebind(`
		UPDATE notification_jobs SET status = ?, last_error = ?, provider_reference = ?,
		next_attempt_at = ?, updated_at = ? WHERE id = ?
	`)
	if nextAttempt.IsZero() {
		nextAttempt = time.Now().UTC()
	}
	result, err := db.ExecContext(ctx, query, status, nullableString(message), nullableString(providerRef),
		nextAttempt, time.Now().UTC(), id)
	if err != nil {
		return err
	}
	affected, err := result.RowsAffected()
	if err != nil {
		return err
	}
	if affected == 0 {
		return ErrNotFound
	}
	return nil
}

func (db *DB) ListNotificationLogs(ctx context.Context, limit int) ([]models.ReportNotification, error) {
	if limit < 1 || limit > 200 {
		limit = 100
	}
	query := db.rebind(`
		SELECT id, report_id, channel, notification_type, status, attempts, created_at, updated_at,
		       next_attempt_at, recipient, last_error, provider_reference
		FROM notification_jobs ORDER BY created_at DESC LIMIT ?
	`)
	rows, err := db.QueryContext(ctx, query, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var logs []models.ReportNotification
	for rows.Next() {
		var item models.ReportNotification
		var nextAttempt sql.NullTime
		var lastError, providerRef sql.NullString
		if err := rows.Scan(&item.ID, &item.ReportID, &item.Channel, &item.Type, &item.Status,
			&item.Attempts, &item.CreatedAt, &item.UpdatedAt, &nextAttempt, &item.Recipient,
			&lastError, &providerRef); err != nil {
			return nil, err
		}
		if item.Status == "processing" {
			item.Status = "pending"
		}
		if nextAttempt.Valid {
			item.NextAttemptAt = &nextAttempt.Time
		}
		if lastError.Valid {
			item.Error = lastError.String
		}
		if providerRef.Valid {
			item.ProviderRef = providerRef.String
		}
		logs = append(logs, item)
	}
	return logs, rows.Err()
}

func (db *DB) RetryNotification(ctx context.Context, id string) error {
	query := db.rebind(`
		UPDATE notification_jobs SET status = 'pending', attempts = 0, next_attempt_at = ?,
		last_error = NULL, updated_at = ? WHERE id = ? AND status = 'failed'
	`)
	now := time.Now().UTC()
	result, err := db.ExecContext(ctx, query, now, now, id)
	if err != nil {
		return err
	}
	affected, err := result.RowsAffected()
	if err != nil {
		return err
	}
	if affected == 0 {
		var exists int
		err := db.QueryRowContext(ctx, db.rebind("SELECT 1 FROM notification_jobs WHERE id = ?"), id).Scan(&exists)
		if errors.Is(err, sql.ErrNoRows) {
			return ErrNotFound
		}
		if err != nil {
			return err
		}
		return ErrConflict
	}
	return nil
}

func (db *DB) GetTrackingReport(ctx context.Context, id string) (*models.Report, error) {
	return db.GetReportByID(ctx, id)
}
