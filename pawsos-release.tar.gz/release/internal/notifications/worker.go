package notifications

import (
	"context"
	"crypto/tls"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"net/smtp"
	"net/url"
	"strconv"
	"strings"
	"time"

	"pawsos/internal/config"
	"pawsos/internal/database"
	"pawsos/internal/tracking"
)

const maxAttempts = 5

type Message struct {
	ReportID    string `json:"report_id"`
	AnimalType  string `json:"animal_type"`
	Urgency     string `json:"urgency"`
	Status      string `json:"status"`
	TrackingURL string `json:"tracking_url"`
}

type permanentError struct{ message string }

func (e permanentError) Error() string { return e.message }

type Worker struct {
	db     *database.DB
	cfg    *config.Config
	client *http.Client
}

func NewWorker(db *database.DB, cfg *config.Config) *Worker {
	return &Worker{
		db:  db,
		cfg: cfg,
		client: &http.Client{
			Timeout: 15 * time.Second,
		},
	}
}

func (w *Worker) Run(ctx context.Context) {
	ticker := time.NewTicker(5 * time.Second)
	defer ticker.Stop()
	for {
		if err := w.processBatch(ctx); err != nil && ctx.Err() == nil {
			log.Printf("[PAWSOS ERROR] Notification queue processing failed: %v", err)
		}
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
		}
	}
}

func (w *Worker) ProcessOnce(ctx context.Context) error {
	return w.processBatch(ctx)
}

func (w *Worker) processBatch(ctx context.Context) error {
	jobs, err := w.db.ClaimDueNotifications(ctx, 10)
	if err != nil {
		return err
	}
	for _, job := range jobs {
		providerRef, sendErr := w.deliver(ctx, job)
		if sendErr == nil {
			if err := w.db.CompleteNotification(ctx, job.ID, "sent", "", providerRef, time.Time{}); err != nil {
				return fmt.Errorf("mark notification %s sent: %w", job.ID, err)
			}
			continue
		}
		status := "pending"
		nextAttempt := time.Now().Add(retryDelay(job.Attempts))
		var permanent permanentError
		if errors.As(sendErr, &permanent) || job.Attempts >= maxAttempts {
			status = "failed"
			nextAttempt = time.Now()
		}
		log.Printf("[PAWSOS WARN] Notification delivery failed (%s, channel=%s, attempt=%d): %v",
			job.ID, job.Channel, job.Attempts, sendErr)
		if err := w.db.CompleteNotification(ctx, job.ID, status, safeError(sendErr), "", nextAttempt); err != nil {
			return fmt.Errorf("record notification failure %s: %w", job.ID, err)
		}
	}
	return nil
}

func retryDelay(attempt int) time.Duration {
	delay := time.Minute * time.Duration(1<<min(attempt-1, 6))
	if delay > time.Hour {
		return time.Hour
	}
	return delay
}

func safeError(err error) string {
	text := strings.TrimSpace(err.Error())
	if len(text) > 500 {
		text = text[:500]
	}
	return text
}

func (w *Worker) deliver(ctx context.Context, job database.NotificationJob) (string, error) {
	var message Message
	if err := json.Unmarshal(job.Payload, &message); err != nil {
		return "", permanentError{"Notification data is invalid"}
	}
	if w.cfg.PublicBaseURL != "" {
		report, err := w.db.GetTrackingReport(ctx, job.ReportID)
		if err != nil {
			return "", fmt.Errorf("load report tracking link: %w", err)
		}
		token, err := tracking.Open(report.TrackingTokenCipher, report.ID, w.cfg.JWTSecret)
		if err != nil {
			return "", permanentError{"Report tracking link is unavailable"}
		}
		message.TrackingURL = strings.TrimRight(w.cfg.PublicBaseURL, "/") + "/track.html?id=" +
			url.QueryEscape(report.ID) + "#token=" + url.QueryEscape(token)
	}
	text := fmt.Sprintf("PawSOS update for %s: %s (%s). Current status: %s.", message.ReportID,
		message.AnimalType, message.Urgency, strings.ReplaceAll(message.Status, "_", " "))
	if message.TrackingURL != "" {
		text += " Track the recorded updates: " + message.TrackingURL
	}
	switch job.Channel {
	case "email":
		return "", w.sendEmail(ctx, job.Recipient, "PawSOS report update: "+message.ReportID, text)
	case "sms":
		return w.sendSMS(ctx, job.Recipient, text)
	default:
		return "", permanentError{"Notification channel is unsupported"}
	}
}

func (w *Worker) sendEmail(ctx context.Context, to, subject, body string) error {
	cfg := w.cfg
	if cfg.SMTPHost == "" || cfg.SMTPFrom == "" || cfg.SMTPUsername == "" || cfg.SMTPPassword == "" {
		return permanentError{"Email provider is not configured"}
	}
	port, err := strconv.Atoi(cfg.SMTPPort)
	if err != nil || port < 1 || port > 65535 {
		return permanentError{"SMTP port configuration is invalid"}
	}
	host := cfg.SMTPHost
	conn, err := (&net.Dialer{Timeout: 10 * time.Second}).DialContext(ctx, "tcp",
		net.JoinHostPort(host, strconv.Itoa(port)))
	if err != nil {
		return err
	}
	defer conn.Close()
	connectionDone := make(chan struct{})
	defer close(connectionDone)
	go func() {
		select {
		case <-ctx.Done():
			_ = conn.Close()
		case <-connectionDone:
		}
	}()
	deadline := time.Now().Add(15 * time.Second)
	if contextDeadline, ok := ctx.Deadline(); ok && contextDeadline.Before(deadline) {
		deadline = contextDeadline
	}
	if err := conn.SetDeadline(deadline); err != nil {
		return err
	}
	client, err := smtp.NewClient(conn, host)
	if err != nil {
		return err
	}
	defer client.Close()
	if err := client.StartTLS(&tls.Config{ServerName: host, MinVersion: tls.VersionTLS12}); err != nil {
		return fmt.Errorf("SMTP STARTTLS failed: %w", err)
	}
	auth := smtp.PlainAuth("", cfg.SMTPUsername, cfg.SMTPPassword, host)
	if err := client.Auth(auth); err != nil {
		return fmt.Errorf("SMTP authentication failed: %w", err)
	}
	if err := client.Mail(cfg.SMTPFrom); err != nil {
		return err
	}
	if err := client.Rcpt(to); err != nil {
		return err
	}
	writer, err := client.Data()
	if err != nil {
		return err
	}
	message := "From: " + cfg.SMTPFrom + "\r\n" +
		"To: " + to + "\r\n" +
		"Subject: " + strings.ReplaceAll(strings.ReplaceAll(subject, "\r", ""), "\n", "") + "\r\n" +
		"MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n" + body + "\r\n"
	if _, err := io.WriteString(writer, message); err != nil {
		_ = writer.Close()
		return err
	}
	return writer.Close()
}

func (w *Worker) sendSMS(ctx context.Context, to, body string) (string, error) {
	cfg := w.cfg
	if cfg.TwilioAccountSID == "" || cfg.TwilioAuthToken == "" ||
		(cfg.TwilioFromNumber == "" && cfg.TwilioMessagingService == "") {
		return "", permanentError{"SMS provider is not configured"}
	}
	form := url.Values{"To": {to}, "Body": {body}}
	if cfg.TwilioMessagingService != "" {
		form.Set("MessagingServiceSid", cfg.TwilioMessagingService)
	} else {
		form.Set("From", cfg.TwilioFromNumber)
	}
	endpoint := "https://api.twilio.com/2010-04-01/Accounts/" +
		url.PathEscape(cfg.TwilioAccountSID) + "/Messages.json"
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, endpoint, strings.NewReader(form.Encode()))
	if err != nil {
		return "", err
	}
	req.SetBasicAuth(cfg.TwilioAccountSID, cfg.TwilioAuthToken)
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	response, err := w.client.Do(req)
	if err != nil {
		return "", err
	}
	defer response.Body.Close()
	responseBody, err := io.ReadAll(io.LimitReader(response.Body, 16*1024))
	if err != nil {
		return "", err
	}
	if response.StatusCode < 200 || response.StatusCode >= 300 {
		if response.StatusCode >= 400 && response.StatusCode < 500 && response.StatusCode != http.StatusTooManyRequests {
			return "", permanentError{fmt.Sprintf("SMS provider rejected the request (HTTP %d)", response.StatusCode)}
		}
		return "", fmt.Errorf("SMS provider returned HTTP %d", response.StatusCode)
	}
	var result struct {
		SID string `json:"sid"`
	}
	if err := json.Unmarshal(responseBody, &result); err != nil {
		return "", fmt.Errorf("SMS provider returned an invalid response: %w", err)
	}
	return result.SID, nil
}
